import { ConvertToSpacePipe } from './convert-to-space.pipe';

describe('ConvertToSpacePipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertToSpacePipe();
    expect(pipe).toBeTruthy();
  });
});
