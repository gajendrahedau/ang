export interface Product {
    productId:number;
    productName:string;starRating:number;
    productCode:number;
    releaseDate:string;
    description:string;
    price:number;
    
}
