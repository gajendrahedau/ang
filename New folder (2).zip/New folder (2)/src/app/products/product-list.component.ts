import { Component, OnInit } from '@angular/core';
import { Product } from './products/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  productListTitle:string='Product List';
  _listFilter:string=''
  error:string;
  productsList:Product[];
  products:Product[];

  constructor(private productService:ProductService) {
    this._listFilter="";
   }
 
  ngOnInit() {
    this.productService.getAllProductsDetails().subscribe(
        tempProducts=>{
          this.products=tempProducts;
          this.productsList=this.products;
        }
      ,
        error=>{
          this.error=error;
        }
    );
  }
  
   doProductFiltering(filterBy:string): Product[]{
    filterBy=filterBy.toLocaleLowerCase();
    return this.products.filter(product=>product.productName.toLowerCase().indexOf(filterBy)!==-1);
  }

  get listFilter(): string{
    return this._listFilter;
  }

  set listFilter(value: string){
    this._listFilter=value;
    this.productsList=this._listFilter?this.doProductFiltering(this._listFilter):this.products;
  }
  
  onRatingClicked(message: string): void{
    this.productListTitle='Products List!!!'+ message;
  }

}
